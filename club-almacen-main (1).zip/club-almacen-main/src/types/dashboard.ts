export interface StatCard {
	id: string;
	title: string;
	value: string | number;
	change: number;
	trend: "up" | "down";
	icon: string;
	color: "blue" | "green" | "yellow" | "red";
}

export interface ChartData {
	name: string;
	value: number;
}

export interface DashboardData {
	stats: StatCard[];
	salesData: ChartData[];
	topProducts: Product[];
}

export interface Product {
	id: string;
	name: string;
	category: string;
	stock: number;
	price: number;
	image?: string;
}
