import { Header } from "../components/layout/Header";
import { Loading } from "../components/ui/Loading";
import { Button } from "../components/ui/Button";
import { StatCard } from "../components/features/StatCard";
import { SalesChart } from "../components/features/SalesChart";
import { TopProducts } from "../components/features/TopProducts";
import { useDashboard } from "../hooks/useDashboard";

export const Home = () => {
	const { data, loading, error, refetch } = useDashboard();

	if (loading) return <Loading />;

	if (error) {
		return (
			<div className="min-h-screen flex items-center justify-center">
				<div className="text-center">
					<p className="text-red-600 mb-4">{error}</p>
					<Button onClick={refetch}>Reintentar</Button>
				</div>
			</div>
		);
	}

	if (!data) return null;

	return (
		<div className="min-h-screen w-full bg-gray-50 flex flex-col">
			<Header />

			<main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
				{/* Welcome Section */}
				<div className="mb-8">
					<h2 className="text-3xl font-bold text-gray-900 mb-2">
						Bienvenido de vuelta 👋
					</h2>
					<p className="text-gray-600">
						Aquí está el resumen de tu negocio hoy
					</p>
				</div>

				{/* Stats Grid */}
				<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
					{data.stats.map((stat) => (
						<StatCard key={stat.id} stat={stat} />
					))}
				</div>

				{/* Charts and Products */}
				<div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
					<div className="lg:col-span-2">
						<SalesChart data={data.salesData} />
					</div>
					<div>
						<TopProducts products={data.topProducts} />
					</div>
				</div>

				{/* Quick Actions */}
				<div className="mt-8 flex flex-wrap gap-4">
					<Button>+ Nuevo Producto</Button>
					<Button variant="secondary">Ver Inventario</Button>
					<Button variant="ghost">Generar Reporte</Button>
				</div>
			</main>
		</div>
	);
};

export default Home;
