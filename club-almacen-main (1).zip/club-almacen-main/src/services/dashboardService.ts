import type { DashboardData } from "../types/dashboard";

// Simulacion de la llamada de nuestro api - reemplazar con APi real en el futuro
export const fetchDashboardData = async (): Promise<DashboardData> => {
	// Simulacion delay de red
	await new Promise((resolve) => setTimeout(resolve, 500));
	return {
		stats: [
			{
				id: "1",
				title: "Ventas Totales",
				value: "$45,231",
				change: 12.5,
				trend: "up",
				icon: "💰",
				color: "blue",
			},
			{
				id: "2",
				title: "Productos",
				value: 1234,
				change: 8.2,
				trend: "up",
				icon: "📦",
				color: "green",
			},
			{
				id: "3",
				title: "Pedidos",
				value: 567,
				change: -3.1,
				trend: "down",
				icon: "📋",
				color: "yellow",
			},
			{
				id: "4",
				title: "Stock Bajo",
				value: 89,
				change: 5.4,
				trend: "up",
				icon: "!",
				color: "red",
			},
		],
		salesData: [
			{ name: "Ene", value: 4000 },
			{ name: "Feb", value: 3000 },
			{ name: "Mar", value: 5000 },
			{ name: "Abr", value: 4500 },
			{ name: "May", value: 6000 },
			{ name: "Jun", value: 5500 },
		],
		topProducts: [
			{
				id: "1",
				name: "Producto Premium A",
				category: "Electrónica",
				stock: 234,
				price: 299.99,
			},
			{
				id: "2",
				name: "Producto Básico B",
				category: "Hogar",
				stock: 156,
				price: 49.99,
			},
			{
				id: "3",
				name: "Producto Elite C",
				category: "Deportes",
				stock: 89,
				price: 189.99,
			},
		],
	};
};
