import { Card } from "../ui/Card";
import type { StatCard as StatCardType } from "../../types/dashboard";

interface StatCardProps {
	stat: StatCardType;
}

export const StatCard = ({ stat }: StatCardProps) => {
	const colorClasses = {
		blue: "text-blue-600 bg-blue-50",
		green: "text-green-600 bg-green-50",
		yellow: "text-yellow-600 bg-yellow-50",
		red: "text-red-600 bg-red-50",
	};

	const trendColor = stat.trend === "up" ? "text-green-600" : "text-red-600";
	const trendIcon = stat.trend === "up" ? "↑" : "↓";

	return (
		<Card className="p-6 hover:shadow-md transition-shadow">
			<div className="flex items-start justify-between">
				<div className="flex-1">
					<p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
					<p className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</p>
					<div className="flex items-center gap-1">
						<span className={`text-sm font-semibold ${trendColor}`}>
							{trendIcon} {Math.abs(stat.change)}%
						</span>
						<span className="text-sm text-gray-500">vs mes anterior</span>
					</div>
				</div>
				<div
					className={`text-4xl ${colorClasses[stat.color]} w-16 h-16 rounded-lg flex items-center justify-center`}
				>
					{stat.icon}
				</div>
			</div>
		</Card>
	);
};
