import { Card } from "../ui/Card";
import type { ChartData } from "../../types/dashboard";

interface SalesChartProps {
	data: ChartData[];
}

export const SalesChart = ({ data }: SalesChartProps) => {
	const maxValue = Math.max(...data.map((d) => d.value));

	return (
		<Card className="p-6 h-full">
			<h3 className="text-lg font-semibold text-gray-900 mb-6">
				Ventas Mensuales
			</h3>
			<div className="h-64 flex items-end justify-between gap-3">
				{data.map((item, index) => {
					const height = (item.value / maxValue) * 100;
					return (
						<div
							key={index}
							className="flex-1 flex flex-col items-center gap-2"
						>
							<div className="w-full h-full bg-gray-100 rounded-t-lg relative group cursor-pointer hover:bg-gray-200 transition-colors">
								<div
									className="w-full bg-blue-600 rounded-t-lg transition-all duration-500 ease-out group-hover:bg-blue-700"
									style={{ height: `${height}%` }}
								>
									<div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap transition-opacity">
										${item.value.toLocaleString()}
									</div>
								</div>
							</div>
							<span className="text-sm text-gray-600 font-medium mt-2">
								{item.name}
							</span>
						</div>
					);
				})}
			</div>
		</Card>
	);
};
