import { Card } from "../ui/Card";
import type { Product } from "../../types/dashboard";

interface TopProductsProps {
	products: Product[];
}

export const TopProducts = ({ products }: TopProductsProps) => {
	return (
		<Card className="p-6">
			<h3 className="text-lg font-semibold text-gray-900 mb-6">
				Productos Destacados
			</h3>
			<div className="space-y-4">
				{products.map((product) => (
					<div
						key={product.id}
						className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
					>
						<div className="flex-1">
							<h4 className="font-semibold text-gray-900 mb-1">
								{product.name}
							</h4>
							<p className="text-sm text-gray-500">{product.category}</p>
						</div>
						<div className="text-right">
							<p className="font-bold text-blue-600 text-lg mb-1">
								${product.price}
							</p>
							<p className="text-sm text-gray-500">Stock: {product.stock}</p>
						</div>
					</div>
				))}
			</div>
		</Card>
	);
};
