import { useState, useEffect } from "react";
import type { DashboardData } from "../types/dashboard";
import { fetchDashboardData } from "../services/dashboardService";

export const useDashboard = () => {
	const [data, setData] = useState<DashboardData | null>(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);

	const loadData = async () => {
		try {
			setLoading(true);
			const result = await fetchDashboardData();
			setData(result);
			setError(null);
		} catch (err) {
			setError("Error al  cargar los datos del dashboard");
			console.error(err);
		} finally {
			setLoading(false);
		}
	};
	useEffect(() => {
		loadData();
	}, []);
	const refetch = async () => {
		await loadData();
	};
	return { data, loading, error, refetch };
};
